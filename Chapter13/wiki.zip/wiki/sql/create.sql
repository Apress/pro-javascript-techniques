CREATE TABLE wiki (
  title varchar(50),
  author varchar(50),
  content text,
  date TIMESTAMP
);
