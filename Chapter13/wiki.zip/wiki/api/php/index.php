<?php
  # Make sure that only severe errors are reported,
  # we'll be handling all of the rest
  error_reporting( 1 );

  # Include the external JSON library
  require_once('JSON.php');

  # Include the SQLite3 shared library: Will probably
  # be different for non-Linux systems
  dl('sqlite3.so');

  # Change the header to display Javascript
  header('Content-type: text/javascript');

  # Create a new JSON renderer
  $json = new Services_JSON();

  # Get the callback from the user
  $call = $_REQUEST['callback'];

  # Get the database name from the user
  $d = $_REQUEST['db'];

  # Make sure the the database name doesn't have
  # any malicious characters in it
  $d = ereg_replace("[^a-zA-Z0-9_-]", "", $d);

  # If no database name was provided, use 'test'
  if ( $d == "" ) $d = "test";
  
  # Get the query arguments

  # The object that will be returned to the client
  $r = array();

  # If a SQL statement was provided
  if ( $sql ) {
    # Capture any thrown exceptions (only available
    # in PHP 5+)
    try {
      # Connect to the SQLite database, which is just a file
      $db = sqlite3_open('../../data/' . $d . '.db');

      # Run the SQL query against the database
      $q = sqlite3_query( $db, $_REQUEST['sql']);

      # If the query was successful
      if ( $q ) {
        # Go through each matched row, if a query was done
        # (e.g. SELECT)
        while ( ( $row = sqlite3_fetch_array($q) ) ) {
          # And add the returned hash onto the return object
          array_push( $r, $row );
        }
      } else {
        # Otherwise an error occurred, so get the
        # last error message from the DB
        $err = sqlite3_error($db);
      }
    } catch ( SQLiteException $e ) {
      # If an exception was thrown by the database
      # capture and save the error message
      $err = $e->getMessage();
    }
  } else {
    # If no SQL query was provided, display an error
    $err = "No query provided.";
  }

  # If an error was thrown, return a hash to the client
  # containing a key of error and a value of the error message
  if ( $err ) {
    $r = array( "error" => $err );
  }

  # Convert the return object to a JSON string
  $jout = $json->encode( $r );

  # If a callback was provided, wrap the returned JSON
  # in it, otherwise just print the straight JSON string
  print $call ?  "$call($jout)" : $jout;
?>
