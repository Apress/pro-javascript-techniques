// Set the name of the database
var db = "wiki";

// We need to wait for the DOM to finish loading
$(document).ready(function(){
  // Try to create a new blog table (it will fail if
  // the table already exists, which is what we want)
  sqlExec( "CREATE TABLE wiki (title varchar(50), " + 
    "author varchar(50), content text, date TIMESTAMP);", [], init );
});

// Handle the initialization of the site - fires after
// the server has responded from the CREATE TABLE...
function init(json) {
  // If our SQL table was created, that means this is
  // the first visit for this user
  if (!json.error) {

    // Go through the sample blog posts
    var total = $("#sample li").size();
    var cur = 0;
    $("#sample li").each(function(){
      // Get each title and text
      var title = $("h2",this).text();
      var text = $("p",this).text();

      // and save each of them to the database
      sqlExec("INSERT INTO wiki VALUES(?,?,?,?);",
        [title,"Anonymous",text,(new Date()).getTime()],
        function(b){
          // Don't display them until all of the new
          // posts have been loaded (avoids flickering)
          if ( ++cur == total )
            done();
        });
    });

  // Otherwise, the user has already been here before,
  // so just load the posts from the database
  } else
    done();
}

// Done!
function done() {
  $("body").html("<h1>Installation Complete</h1>" + 
    "<a href='./?HomePage'>Visit Your Wiki</a>");
}
