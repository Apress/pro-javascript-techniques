// UPDATE THIS VARIABLE
// The URL where your Server-Side script is
var apiURL = "api/ruby/";

// Some default global variables
var sqlLoaded = function(){};

// Handle a long SQL Submission
// This function is capable of sending large amounts of
// data (e.g. a large INSERT), but is only able to send
// to locations on the same server as the client
function sqlExec(q, p, callback) {
  
  // Load all the arguments into a structured array
  for ( var i = 0; i < p.length; i++ ) {
    p[i] = { name: "arg", value: p[i] }; 
  }
  
  // Include the name of the database
  p.push({ name: "db", value: db });
  
  // And the name of the SQL query to execute
  p.push({ name: "sql", value: q });

  // Submit the query to the server
  $.ajax({
    // POST to the API URL
    type: "POST",
    url: apiURL,
    
    // Serialize the array of data
    data: $.param(p),
    
    // We're expecting JSON data coming back
    dataType: "json",
    
    // Wait for the request to finish successfully
    // If a callback was specified by the user, send the data back
    success: callback
  });

}
